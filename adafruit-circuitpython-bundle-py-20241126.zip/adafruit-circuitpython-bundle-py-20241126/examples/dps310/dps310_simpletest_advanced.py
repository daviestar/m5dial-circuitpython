# SPDX-FileCopyrightText: 2021 Jose David M.
# SPDX-License-Identifier: MIT

import time
import board
from adafruit_dps310.advanced import DPS310_Advanced as DPS310

i2c = board.I2C()  # uses board.SCL and board.SDA
# i2c = board.STEMMA_I2C()  # For using the built-in STEMMA QT connector on a microcontroller
dps310 = DPS310(i2c)

while True:
    print("Temperature = %.2f *C" % dps310.temperature)
    print("Pressure = %.2f hPa" % dps310.pressure)
    print("")
    time.sleep(1.0)
